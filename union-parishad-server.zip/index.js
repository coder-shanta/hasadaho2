const express = require('express');
const mysql = require('mysql2');
// const mysql = require('mysql');
const cors = require('cors');
require('dotenv').config();
const bodyParser = require('body-parser');
const fileUpload = require('express-fileupload');

const app = express();
const port = process.env.PORT || 5000;

app.use(bodyParser.json());
app.use(cors());
app.use(fileUpload());

const db = mysql.createConnection({
    user: 'root',
    host: 'localhost',
    password: 'mySql@015#',
    database: 'union_parishad'
});

// Residential Start
// Post Data
app.post('/resident', (req, res) => {
    const holding_no = req.body.holding_no;
    const assign_tax = req.body.assign_tax;
    const payer_name = req.body.payer_name;
    const total_tax = req.body.total_tax;
    const guardian_name = req.body.guardian_name;
    const collected_tax = req.body.collected_tax;
    const word_no = req.body.word_no;
    const areas_tax = req.body.areas_tax;
    const village = req.body.village;
    const mobile_no = req.body.mobile_no;
    const previes_areas_tax = req.body.previes_areas_tax;
    console.log(req.body);
    db.query("INSERT INTO resident_table (holding_no, assign_tax, payer_name, total_tax, guardian_name, collected_tax, word_no, areas_tax, village, mobile_no, previes_areas_tax) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [holding_no, assign_tax, payer_name, total_tax, guardian_name, collected_tax, word_no, areas_tax, village, mobile_no, previes_areas_tax], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    });
});

// Get Data
app.get('/resident', (req, res) => {
    db.query("SELECT * FROM resident_table", (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    });
});

// Get a Data
app.get('/resident/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    db.query("SELECT * FROM resident_table  WHERE id = ?", id, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    })
});

// Update Data
app.put('/resident/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    const holding_no = req.body.holding_no;
    const assign_tax = req.body.assign_tax;
    const payer_name = req.body.payer_name;
    const total_tax = req.body.total_tax;
    const guardian_name = req.body.guardian_name;
    const collected_tax = req.body.collected_tax;
    const word_no = req.body.word_no;
    const areas_tax = req.body.areas_tax;
    const village = req.body.village;
    const mobile_no = req.body.mobile_no;
    const previes_areas_tax = req.body.previes_areas_tax;
    db.query("UPDATE resident_table SET holding_no = ?, assign_tax = ?, payer_name=?,total_tax=?,guardian_name=?,collected_tax=?,word_no=? ,areas_tax=?, village=?, mobile_no=?, previes_areas_tax=? WHERE id = ?", [holding_no, assign_tax, payer_name, total_tax, guardian_name, collected_tax, word_no, areas_tax, village, mobile_no, previes_areas_tax, id], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    });
});

// Delate Data
app.delete('/resident/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    db.query("DELETE FROM resident_table WHERE id = ?", id, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    })
});
// Residential End

// Commercial Start
// Post Data
app.post('/commerce', (req, res) => {
    const holding_no = req.body.holding_no;
    const assign_tax = req.body.assign_tax;
    const payer_name = req.body.payer_name;
    const total_tax = req.body.total_tax;
    const guardian_name = req.body.guardian_name;
    const collected_tax = req.body.collected_tax;
    const word_no = req.body.word_no;
    const areas_tax = req.body.areas_tax;
    const village = req.body.village;
    const mobile_no = req.body.mobile_no;
    const previes_areas_tax = req.body.previes_areas_tax;
    console.log(req.body);
    db.query("INSERT INTO commerce_table (holding_no, assign_tax, payer_name, total_tax, guardian_name, collected_tax, word_no, areas_tax, village, mobile_no, previes_areas_tax) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [holding_no, assign_tax, payer_name, total_tax, guardian_name, collected_tax, word_no, areas_tax, village, mobile_no, previes_areas_tax], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    });
});

// Get Data
app.get('/commerce', (req, res) => {
    db.query("SELECT * FROM commerce_table", (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    });
});

// Get a Data
app.get('/commerce/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    db.query("SELECT * FROM commerce_table  WHERE id = ?", id, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    })
});

// Update Data
app.put('/commerce/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    const holding_no = req.body.holding_no;
    const assign_tax = req.body.assign_tax;
    const payer_name = req.body.payer_name;
    const total_tax = req.body.total_tax;
    const guardian_name = req.body.guardian_name;
    const collected_tax = req.body.collected_tax;
    const word_no = req.body.word_no;
    const areas_tax = req.body.areas_tax;
    const village = req.body.village;
    const mobile_no = req.body.mobile_no;
    const previes_areas_tax = req.body.previes_areas_tax;
    db.query("UPDATE commerce_table SET holding_no = ?, assign_tax = ?, payer_name=?,total_tax=?,guardian_name=?,collected_tax=?,word_no=? ,areas_tax=?, village=?, mobile_no=?, previes_areas_tax=? WHERE id = ?", [holding_no, assign_tax, payer_name, total_tax, guardian_name, collected_tax, word_no, areas_tax, village, mobile_no, previes_areas_tax, id], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    });
});

// Delate Data
app.delete('/commerce/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    db.query("DELETE FROM commerce_table WHERE id = ?", id, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    })
});
// Commercial End

// Tread License Start
// Post Data
app.post('/tread_license', (req, res) => {
    const license_no = req.body.license_no;
    const institute_address = req.body.institute_address;
    const institute_name = req.body.institute_name;
    const profession_capital = req.body.profession_capital;
    const owner_name = req.body.owner_name;
    const license_fee = req.body.license_fee;
    const guardian_name = req.body.guardian_name;
    const arrears = req.body.arrears;
    const mothers_name = req.body.mothers_name;
    const total = req.body.total;
    const address = req.body.address;
    const in_words = req.body.in_words;
    const business_type = req.body.business_type;
    const mobile_no = req.body.mobile_no;
    console.log(req.body);
    db.query("INSERT INTO tread_license_table (license_no, institute_address, institute_name, profession_capital, owner_name, license_fee, guardian_name, arrears, mothers_name, total, address, in_words, business_type, mobile_no) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [license_no, institute_address, institute_name, profession_capital, owner_name, license_fee, guardian_name, arrears, mothers_name, total, address, in_words, business_type, mobile_no], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    });
});

// Get Data
app.get('/tread_license', (req, res) => {
    db.query("SELECT * FROM tread_license_table", (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    });
});

// Get a Data
app.get('/tread_license/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    db.query("SELECT * FROM tread_license_table  WHERE id = ?", id, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    })
});

// Update Data
app.put('/tread_license/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    const license_no = req.body.license_no;
    const institute_address = req.body.institute_address;
    const institute_name = req.body.institute_name;
    const profession_capital = req.body.profession_capital;
    const owner_name = req.body.owner_name;
    const license_fee = req.body.license_fee;
    const guardian_name = req.body.guardian_name;
    const arrears = req.body.arrears;
    const mothers_name = req.body.mothers_name;
    const total = req.body.total;
    const address = req.body.address;
    const in_words = req.body.in_words;
    const business_type = req.body.business_type;
    const mobile_no = req.body.mobile_no;
    db.query("UPDATE tread_license_table SET license_no = ?, institute_address = ?, institute_name = ?, profession_capital = ?, owner_name = ?, license_fee = ?, guardian_name =? , arrears = ?, mothers_name = ?, total = ?, address = ?, in_words = ?, business_type = ?, mobile_no = ? WHERE id = ?", [license_no, institute_address, institute_name, profession_capital, owner_name, license_fee, guardian_name, arrears, mothers_name, total, address, in_words, business_type, mobile_no, id], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    });
});

// Delate Data
app.delete('/tread_license/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    db.query("DELETE FROM tread_license_table WHERE id = ?", id, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    })
});
// Tread License End

// Character Certificate Start
// Post Data
app.post('/character_certificate', (req, res) => {
    const memorandum_no = req.body.memorandum_no;
    const village = req.body.village;
    const applicant_name = req.body.applicant_name;
    const post_office = req.body.post_office;
    const guardian_name = req.body.guardian_name;
    const word_no = req.body.word_no;
    const mother_name = req.body.mother_name;
    const marital_status = req.body.marital_status;
    console.log(req.body);
    db.query("INSERT INTO character_certificate (memorandum_no, village, applicant_name, post_office, guardian_name, word_no, mother_name, marital_status) VALUES(?, ?, ?, ?, ?, ?, ?, ?)", [memorandum_no, village, applicant_name, post_office, guardian_name, word_no, mother_name, marital_status], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    });
});

// Get Data
app.get('/character_certificate', (req, res) => {
    db.query("SELECT * FROM character_certificate", (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    });
});

// Get a Data
app.get('/character_certificate/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    db.query("SELECT * FROM character_certificate  WHERE id = ?", id, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    })
});

// Update Data
app.put('/character_certificate/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    const memorandum_no = req.body.memorandum_no;
    const village = req.body.village;
    const applicant_name = req.body.applicant_name;
    const post_office = req.body.post_office;
    const guardian_name = req.body.guardian_name;
    const word_no = req.body.word_no;
    const mother_name = req.body.mother_name;
    const marital_status = req.body.marital_status;
    db.query("UPDATE character_certificate SET memorandum_no = ?, village = ?, applicant_name = ?, post_office = ?, guardian_name = ?, word_no = ?, mother_name =? , marital_status = ? WHERE id = ?", [memorandum_no, village, applicant_name, post_office, guardian_name, word_no, mother_name, marital_status, id], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    });
});

// Delate Data
app.delete('/character_certificate/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    db.query("DELETE FROM character_certificate WHERE id = ?", id, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    })
});
// Character Certificate End

// Citizen Certificate Start
// Post Data
app.post('/citizen_certificate', (req, res) => {
    const memorandum_no = req.body.memorandum_no;
    const village = req.body.village;
    const applicant_name = req.body.applicant_name;
    const post_office = req.body.post_office;
    const guardian_name = req.body.guardian_name;
    const word_no = req.body.word_no;
    const mother_name = req.body.mother_name;
    const marital_status = req.body.marital_status;
    console.log(req.body);
    db.query("INSERT INTO citizen_certificate (memorandum_no, village, applicant_name, post_office, guardian_name, word_no, mother_name, marital_status) VALUES(?, ?, ?, ?, ?, ?, ?, ?)", [memorandum_no, village, applicant_name, post_office, guardian_name, word_no, mother_name, marital_status], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    });
});

// Get Data
app.get('/citizen_certificate', (req, res) => {
    db.query("SELECT * FROM citizen_certificate", (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    });
});

// Get a Data
app.get('/citizen_certificate/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    db.query("SELECT * FROM citizen_certificate  WHERE id = ?", id, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    })
});

// Update Data
app.put('/citizen_certificate/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    const memorandum_no = req.body.memorandum_no;
    const village = req.body.village;
    const applicant_name = req.body.applicant_name;
    const post_office = req.body.post_office;
    const guardian_name = req.body.guardian_name;
    const word_no = req.body.word_no;
    const mother_name = req.body.mother_name;
    const marital_status = req.body.marital_status;
    db.query("UPDATE citizen_certificate SET memorandum_no = ?, village = ?, applicant_name = ?, post_office = ?, guardian_name = ?, word_no = ?, mother_name =? , marital_status = ? WHERE id = ?", [memorandum_no, village, applicant_name, post_office, guardian_name, word_no, mother_name, marital_status, id], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    });
});

// Delate Data
app.delete('/citizen_certificate/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    db.query("DELETE FROM citizen_certificate WHERE id = ?", id, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    })
});
// Citizen Certificate End

// Inheritance Certificate Start
// Post Data
app.post('/inheritance_certificate', (req, res) => {
    const memorandum_no = req.body.memorandum_no;
    const village = req.body.village;
    const applicant_name = req.body.applicant_name;
    const post_office = req.body.post_office;
    const guardian_name = req.body.guardian_name;
    const word_no = req.body.word_no;
    const mother_name = req.body.mother_name;
    const marital_status = req.body.marital_status;
    console.log(req.body);
    db.query("INSERT INTO inheritance_certificate (memorandum_no, village, applicant_name, post_office, guardian_name, word_no, mother_name, marital_status) VALUES(?, ?, ?, ?, ?, ?, ?, ?)", [memorandum_no, village, applicant_name, post_office, guardian_name, word_no, mother_name, marital_status], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    });
});

// Get Data
app.get('/inheritance_certificate', (req, res) => {
    db.query("SELECT * FROM inheritance_certificate", (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    });
});

// Get a Data
app.get('/inheritance_certificate/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    db.query("SELECT * FROM inheritance_certificate  WHERE id = ?", id, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    })
});

// Update Data
app.put('/inheritance_certificate/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    const memorandum_no = req.body.memorandum_no;
    const village = req.body.village;
    const applicant_name = req.body.applicant_name;
    const post_office = req.body.post_office;
    const guardian_name = req.body.guardian_name;
    const word_no = req.body.word_no;
    const mother_name = req.body.mother_name;
    const marital_status = req.body.marital_status;
    db.query("UPDATE inheritance_certificate SET memorandum_no = ?, village = ?, applicant_name = ?, post_office = ?, guardian_name = ?, word_no = ?, mother_name =? , marital_status = ? WHERE id = ?", [memorandum_no, village, applicant_name, post_office, guardian_name, word_no, mother_name, marital_status, id], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    });
});

// Delate Data
app.delete('/inheritance_certificate/:id', (req, res) => {
    const id = req.params.id;
    console.log(id);
    db.query("DELETE FROM inheritance_certificate WHERE id = ?", id, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    })
});
// Inheritance Certificate End

// Notice Start
/* app.post('/notice', (req, res) => {
    const title = req.body.title;
    const subtitle = req.body.subtitle;
    const desc = req.body.desc;
    let image = req.files.image;
    // const uploadPath = __dirname + '/upload/' + image.name;

    // image.mv(uploadPath, function (err){
    //     if (err) return res.status(500).send(err);
    //     res.send('fileUpload')
    // })

    const imgData = image.data;
    const encodedImg = imgData.toString('base64');
    const imgBuffer = Buffer.from(encodedImg, 'base64');
    console.log(title, subtitle, desc, imgBuffer);

    db.query("INSERT INTO notice_table(title, subtitle, desc, imgBuffer) VALUES(? , ? , ? , ?)", [title, subtitle, desc, imgBuffer], (err, result) =>{
        if(err){
            console.log(err);
        }else{
            res.send(result);
        }
    });
}); */
app.post('/notice', (req, res) => {
    const title = req.body.title;
    const subtitle = req.body.subtitle;
    const desc = req.body.desc;
    // const image = req.body.image[0];
    console.log(title, subtitle, desc);
   
    db.query("INSERT INTO notice (title, sub_title, desc) VALUES (?, ?, ?)", [title, subtitle, desc], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    });
});
// Notice End


app.get('/', (req, res) => {
    res.send('Server is Running...')
});

app.listen(port, () => {
    console.log(`running on port ${port}`);
});









/* 
`id` INT NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(45) NOT NULL,
  `sub_title` VARCHAR(45) NOT NULL,
  `desc` VARCHAR(255) NOT NULL,
  `image` VARCHAR(255) NOT NULL,
*/
